from django.contrib import admin
from desk.models import FinancialOperation

# Register your models here.
admin.site.register(FinancialOperation)
