#!/usr/bin/env bash
# Requires python27

python manage.py runserver